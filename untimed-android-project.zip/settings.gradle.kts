// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "Untimed"
include(
    ":app",
    ":core:model", ":core:data", ":core:engine", ":core:service", ":core:ui",
    ":feature:bank", ":feature:blocks", ":feature:settings", ":feature:stats",
)
