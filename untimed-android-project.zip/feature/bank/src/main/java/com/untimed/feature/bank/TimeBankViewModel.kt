// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.feature.bank

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.untimed.core.data.ServiceLauncher
import com.untimed.core.data.SessionRepository
import com.untimed.core.engine.BankMode
import com.untimed.core.engine.TimeBankEngine
import com.untimed.core.model.BucketTag
import com.untimed.core.model.RatioPreset
import com.untimed.core.model.SurgeTier
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

data class TimeBankUiState(
    val remainingMs: Long = 0,
    val elapsedMs: Long = 0,
    val ratio: Int = 5,
    val surgeTier: SurgeTier = SurgeTier.NONE,
    val isRunning: Boolean = false,
    /** Added beyond Table E so the UI can tell a work run from a rest countdown (see G-B05). */
    val isResting: Boolean = false,
    val bucketTag: BucketTag? = null,
    val presetId: Long? = null,
)

sealed interface TimeBankEvent {
    data object Start : TimeBankEvent
    data object Pause : TimeBankEvent
    data object Reset : TimeBankEvent
    data class SetRatio(val preset: RatioPreset) : TimeBankEvent
    data class SetBucket(val tag: BucketTag?) : TimeBankEvent
    data object CashOut : TimeBankEvent
}

@HiltViewModel
class TimeBankViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val engine: TimeBankEngine,
    sessions: SessionRepository,
) : ViewModel() {

    val uiState: StateFlow<TimeBankUiState> = engine.state
        .map { s ->
            TimeBankUiState(
                remainingMs = s.bankMs,
                elapsedMs = s.elapsedMs,
                ratio = s.workRatio,
                surgeTier = s.surgeTier,
                isRunning = s.mode != BankMode.IDLE,
                isResting = s.mode == BankMode.RESTING,
                bucketTag = s.bucket,
                presetId = s.presetId,
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), TimeBankUiState())

    val presets: StateFlow<List<RatioPreset>> =
        sessions.presets.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val tags: StateFlow<List<BucketTag>> =
        sessions.tags.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun onEvent(event: TimeBankEvent) {
        when (event) {
            TimeBankEvent.Start -> {
                engine.start() // state changes first so the service never sees a stale idle state
                ServiceLauncher.startTimer(context)
            }
            TimeBankEvent.Pause -> engine.pause()
            TimeBankEvent.Reset -> engine.reset()
            is TimeBankEvent.SetRatio -> engine.setRatio(event.preset)
            is TimeBankEvent.SetBucket -> engine.setBucket(event.tag)
            TimeBankEvent.CashOut -> {
                engine.cashOut()
                ServiceLauncher.startTimer(context)
            }
        }
    }
}
