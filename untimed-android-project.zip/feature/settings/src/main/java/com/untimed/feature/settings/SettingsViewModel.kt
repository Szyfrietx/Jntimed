// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.feature.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.untimed.core.data.ServiceLauncher
import com.untimed.core.data.SessionRepository
import com.untimed.core.data.SettingsRepository
import com.untimed.core.model.BucketTag
import com.untimed.core.model.RatioPreset
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    /** Primary, secondary, tertiary as #AARRGGBB. */
    val palette: List<String> = emptyList(),
    val decayPercent: Int = 50,
    val overlayEnabled: Boolean = false,
    val wakeLockEnabled: Boolean = false,
    val soundEnabled: Boolean = true,
    val hapticEnabled: Boolean = true,
)

sealed interface SettingsEvent {
    data class SetPalette(val palette: List<String>) : SettingsEvent
    data class SetDecay(val percent: Int) : SettingsEvent
    data class ToggleOverlay(val enabled: Boolean) : SettingsEvent
    data class ToggleWakeLock(val enabled: Boolean) : SettingsEvent
    data class ToggleSound(val enabled: Boolean) : SettingsEvent
    data class ToggleHaptic(val enabled: Boolean) : SettingsEvent
    /** Weight is snapped to 0.1 steps within 0.5–2.0 by the repository (A-11). */
    data class AddBucket(val name: String, val weight: Float) : SettingsEvent
    data class AddPreset(val workRatio: Int) : SettingsEvent
}

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: SettingsRepository,
    private val sessions: SessionRepository,
) : ViewModel() {

    val tags: StateFlow<List<BucketTag>> =
        sessions.tags.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val presets: StateFlow<List<RatioPreset>> =
        sessions.presets.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val uiState: StateFlow<SettingsUiState> = repository.settings
        .map { s ->
            SettingsUiState(s.palette, s.decayPercent, s.overlayEnabled, s.wakeLockEnabled, s.soundEnabled, s.hapticEnabled)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState())

    fun onEvent(event: SettingsEvent) {
        viewModelScope.launch {
            when (event) {
                is SettingsEvent.SetPalette -> repository.setPalette(event.palette)
                is SettingsEvent.SetDecay -> repository.setDecayPercent(event.percent)
                is SettingsEvent.ToggleOverlay -> {
                    repository.setOverlayEnabled(event.enabled)
                    ServiceLauncher.setOverlay(context, event.enabled)
                }
                is SettingsEvent.ToggleWakeLock -> repository.setWakeLockEnabled(event.enabled)
                is SettingsEvent.ToggleSound -> repository.setSoundEnabled(event.enabled)
                is SettingsEvent.ToggleHaptic -> repository.setHapticEnabled(event.enabled)
                is SettingsEvent.AddBucket -> sessions.upsertTag(event.name, event.weight, "#FF6750A4")
                is SettingsEvent.AddPreset -> sessions.addPreset(event.workRatio)
            }
        }
    }
}
