// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.service

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.untimed.core.data.SettingsRepository
import com.untimed.core.engine.BankMode
import com.untimed.core.engine.BankState
import com.untimed.core.engine.ChainState
import com.untimed.core.engine.EngineEvent
import com.untimed.core.engine.SequentialBlockEngine
import com.untimed.core.engine.SurgeCalculator
import com.untimed.core.engine.TimeBankEngine
import com.untimed.core.model.formatClock
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.math.abs

/**
 * Keeps the process alive while a bank or chain runs, mirrors state into the notification, and plays
 * sound/haptics for engine events. Stops itself once both engines have been idle for 3 seconds.
 */
@AndroidEntryPoint
class TimerForegroundService : Service() {
    @Inject lateinit var bank: TimeBankEngine
    @Inject lateinit var chain: SequentialBlockEngine
    @Inject lateinit var notifications: NotificationBuilder
    @Inject lateinit var sound: SoundPlayer
    @Inject lateinit var haptics: HapticFeedbackHelper
    @Inject lateinit var settings: SettingsRepository
    @Inject lateinit var alarms: AlarmScheduler

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var observing = false
    private var alarmAtMs = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        notifications.createChannels()
        ServiceCompat.startForeground(
            this,
            NotificationBuilder.ID_TIMER,
            notifications.timerNotification("Untimed", "Starting"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
        )
        if (!observing) {
            observing = true
            observe()
        }
        return START_STICKY
    }

    @OptIn(FlowPreview::class)
    private fun observe() {
        scope.launch {
            merge(bank.events, chain.events).collect { event ->
                val s = settings.settings.first()
                when (event) {
                    is EngineEvent.SurgeBoundary -> signal(s.soundEnabled, s.hapticEnabled, SoundPlayer.BOUNDARY)
                    EngineEvent.BankDepleted -> {
                        signal(s.soundEnabled, s.hapticEnabled, SoundPlayer.DEPLETION)
                        notifications.alert("Bank empty", "Time to get back to work.")
                    }
                    is EngineEvent.BlockAlert -> {
                        signal(s.soundEnabled, s.hapticEnabled, SoundPlayer.ALERT)
                        notifications.alert("Block started", event.title)
                    }
                    EngineEvent.ChainFinished -> {
                        signal(s.soundEnabled, s.hapticEnabled, SoundPlayer.DEPLETION)
                        notifications.alert("Chain complete", "All blocks finished.")
                    }
                }
            }
        }
        scope.launch {
            combine(bank.state, chain.state) { b, c -> describe(b, c) }
                .conflate()
                .collect { (title, text) ->
                    notifications.updateTimer(notifications.timerNotification(title, text))
                    delay(1000)
                }
        }
        scope.launch {
            combine(bank.state, chain.state) { b, c -> nextBoundaryMs(b, c) }
                .conflate()
                .collect { syncAlarm(it) ; delay(1000) }
        }
        scope.launch {
            combine(bank.state, chain.state) { b, c -> b.mode == BankMode.IDLE && !c.running }
                .debounce(IDLE_GRACE_MS)
                .collect { idle ->
                    if (idle) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    }
                }
        }
    }

    /** Milliseconds until the next surge tier, block end or rest end; null when nothing is pending. */
    private fun nextBoundaryMs(b: BankState, c: ChainState): Long? {
        val candidates = mutableListOf<Long>()
        if (b.mode == BankMode.RESTING && b.bankMs > 0) candidates += b.bankMs
        if (b.mode == BankMode.WORKING) {
            when {
                b.elapsedMs < SurgeCalculator.TIER_1_MS -> candidates += SurgeCalculator.TIER_1_MS - b.elapsedMs
                b.elapsedMs < SurgeCalculator.TIER_2_MS -> candidates += SurgeCalculator.TIER_2_MS - b.elapsedMs
            }
        }
        if (c.running && c.remainingMs > 0) candidates += c.remainingMs
        return candidates.minOrNull()
    }

    private fun syncAlarm(delayMs: Long?) {
        if (delayMs == null) {
            if (alarmAtMs != 0L) alarms.cancel()
            alarmAtMs = 0L
            return
        }
        val target = System.currentTimeMillis() + delayMs
        if (abs(target - alarmAtMs) > ALARM_TOLERANCE_MS) {
            alarms.scheduleAt(target)
            alarmAtMs = target
        }
    }

    private fun signal(sound: Boolean, haptic: Boolean, name: String) {
        if (sound) this.sound.play(name)
        if (haptic) haptics.pulse()
    }

    private fun describe(b: BankState, c: ChainState): Pair<String, String> {
        val bankText = when (b.mode) {
            BankMode.WORKING -> "Working ${formatClock(b.elapsedMs)} · Bank ${formatClock(b.bankMs)}"
            BankMode.RESTING -> "Resting · ${formatClock(b.bankMs)} left"
            BankMode.IDLE -> "Bank ${formatClock(b.bankMs)}"
        }
        return if (c.running) {
            (c.activeTitle ?: "Block") to "${formatClock(c.remainingMs)} left · $bankText"
        } else {
            "Untimed" to bankText
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private companion object {
        const val IDLE_GRACE_MS = 3000L
        const val ALARM_TOLERANCE_MS = 2000L
    }
}
