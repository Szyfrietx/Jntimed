// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationBuilder @Inject constructor(
    @ApplicationContext private val context: Context,
    private val manager: NotificationManager,
) {
    companion object {
        const val CHANNEL_TIMER = "untimed_timer"
        const val CHANNEL_ALERTS = "untimed_alerts"
        const val ID_TIMER = 1
        const val ID_OVERLAY = 2
        const val ID_ALERT = 3
    }

    /** Creates both channels. Safe to call repeatedly. */
    fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_TIMER, "Timer", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Running timer status"
            },
        )
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERTS, "Alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Block starts, bank depletion"
            },
        )
    }

    fun timerNotification(title: String, text: String): Notification =
        base(CHANNEL_TIMER, title, text).setOngoing(true).setOnlyAlertOnce(true).build()

    fun overlayNotification(): Notification =
        base(CHANNEL_TIMER, "Untimed overlay", "Floating bubble is active").setOngoing(true).build()

    fun updateTimer(notification: Notification) = manager.notify(ID_TIMER, notification)

    fun alert(title: String, text: String) {
        manager.notify(ID_ALERT, base(CHANNEL_ALERTS, title, text).setAutoCancel(true).build())
    }

    /** Resolves the app's ic_notification by name (this module cannot see :app's R); falls back to a system icon. */
    private fun smallIcon(): Int {
        val own = context.resources.getIdentifier("ic_notification", "drawable", context.packageName)
        return if (own != 0) own else android.R.drawable.ic_lock_idle_alarm
    }

    private fun base(channel: String, title: String, text: String): NotificationCompat.Builder {
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
        val pending = launch?.let {
            PendingIntent.getActivity(context, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
        return NotificationCompat.Builder(context, channel)
            .setSmallIcon(smallIcon())
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pending)
    }
}
