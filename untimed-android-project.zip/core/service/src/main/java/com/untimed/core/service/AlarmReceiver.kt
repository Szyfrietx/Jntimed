// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.untimed.core.data.ServiceLauncher

/** Alarm target. Starting the timer service revives the engines, which then fire the due chime. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ServiceLauncher.startTimer(context)
    }
}
