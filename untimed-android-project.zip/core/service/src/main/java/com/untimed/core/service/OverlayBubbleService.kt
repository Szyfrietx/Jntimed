// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.service

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ServiceCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.untimed.core.data.AppSettings
import com.untimed.core.data.SettingsRepository
import com.untimed.core.engine.SurgeCalculator
import com.untimed.core.engine.TimeBankEngine
import com.untimed.core.model.formatClock
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Snapshot of the bubble UI (Table E). Position is tracked in WindowManager.LayoutParams. */
data class OverlayState(val isExpanded: Boolean, val position: Offset, val remainingMs: Long)

/**
 * Floating bubble drawn with SYSTEM_ALERT_WINDOW. Tap expands or collapses, drag repositions,
 * long press dismisses. Without the permission it stops and clears the setting, leaving the
 * notification as the only surface (T-03).
 */
@AndroidEntryPoint
class OverlayBubbleService : Service() {
    @Inject lateinit var bank: TimeBankEngine
    @Inject lateinit var settings: SettingsRepository
    @Inject lateinit var notifications: NotificationBuilder

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val owner = OverlayOwner()
    private var windowManager: WindowManager? = null
    private var bubble: ComposeView? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        notifications.createChannels()
        ServiceCompat.startForeground(
            this,
            NotificationBuilder.ID_OVERLAY,
            notifications.overlayNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
        )
        if (!Settings.canDrawOverlays(this)) {
            scope.launch { settings.setOverlayEnabled(false) }
            stopSelf()
            return START_NOT_STICKY
        }
        if (bubble == null) attachBubble()
        return START_STICKY
    }

    private fun attachBubble() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 240
        }
        owner.create()
        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setContent {
                Bubble(
                    bank = bank,
                    settings = settings,
                    onDrag = { dx, dy ->
                        lp.x += dx.toInt()
                        lp.y += dy.toInt()
                        wm.updateViewLayout(this, lp)
                    },
                    onDismiss = {
                        scope.launch { settings.setOverlayEnabled(false) }
                        stopSelf()
                    },
                )
            }
        }
        wm.addView(view, lp)
        owner.resume()
        windowManager = wm
        params = lp
        bubble = view
    }

    override fun onDestroy() {
        bubble?.let { runCatching { windowManager?.removeView(it) } }
        bubble = null
        owner.destroy()
        scope.cancel()
        super.onDestroy()
    }
}

@Composable
private fun Bubble(
    bank: TimeBankEngine,
    settings: SettingsRepository,
    onDrag: (Float, Float) -> Unit,
    onDismiss: () -> Unit,
) {
    val state by bank.state.collectAsState()
    val prefs by settings.settings.collectAsState(initial = AppSettings())
    var expanded by remember { mutableStateOf(false) }
    val overlay = OverlayState(expanded, Offset.Zero, state.bankMs)
    val fill = hexToColor(prefs.primaryHex)
    val progress = (state.elapsedMs.toFloat() / SurgeCalculator.TIER_2_MS).coerceIn(0f, 1f)

    Box(
        modifier = Modifier
            .size(if (overlay.isExpanded) 200.dp else 56.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(fill)
            .pointerInput(Unit) {
                detectTapGestures(onTap = { expanded = !expanded }, onLongPress = { onDismiss() })
            }
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    onDrag(drag.x, drag.y)
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(if (overlay.isExpanded) 188.dp else 48.dp)) {
            drawArc(
                color = Color.White,
                startAngle = -90f,
                sweepAngle = 360f * progress,
                useCenter = false,
                topLeft = Offset.Zero,
                size = Size(size.width, size.height),
                style = Stroke(width = 4.dp.toPx()),
            )
        }
        Text(
            text = formatClock(overlay.remainingMs),
            color = Color.White,
            fontSize = if (overlay.isExpanded) 32.sp else 11.sp,
        )
    }
}

private fun hexToColor(hex: String): Color =
    try { Color(android.graphics.Color.parseColor(hex)) } catch (e: IllegalArgumentException) { Color(0xFF6750A4) }

/** Minimal lifecycle host so Compose can run inside a Service window. */
private class OverlayOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val registry = LifecycleRegistry(this)
    private val controller = SavedStateRegistryController.create(this)
    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
    override val viewModelStore: ViewModelStore = ViewModelStore()

    fun create() {
        controller.performRestore(null)
        registry.currentState = Lifecycle.State.CREATED
    }

    fun resume() {
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun destroy() {
        registry.currentState = Lifecycle.State.DESTROYED
        viewModelStore.clear()
    }
}
