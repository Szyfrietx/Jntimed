// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.engine

import android.os.SystemClock
import com.untimed.core.data.EngineSnapshot
import com.untimed.core.data.SessionRepository
import com.untimed.core.data.SettingsRepository
import com.untimed.core.data.dayKey
import com.untimed.core.data.daysBetween
import com.untimed.core.model.BucketTag
import com.untimed.core.model.RatioPreset
import com.untimed.core.model.SurgeTier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.jvm.Synchronized
import kotlin.math.pow

enum class BankMode { IDLE, WORKING, RESTING }

data class BankState(
    val mode: BankMode = BankMode.IDLE,
    val elapsedMs: Long = 0,
    val bankMs: Long = 0,
    val workRatio: Int = 5,
    val restRatio: Int = 1,
    val surgeTier: SurgeTier = SurgeTier.NONE,
    val bucket: BucketTag? = null,
    val presetId: Long? = null,
)

/** One-shot signals for sound, haptics and alert notifications. Shared by both engines. */
sealed interface EngineEvent {
    data class SurgeBoundary(val tier: SurgeTier) : EngineEvent
    data object BankDepleted : EngineEvent
    data class BlockAlert(val title: String) : EngineEvent
    data object ChainFinished : EngineEvent
}

/**
 * Stopwatch-to-countdown engine. Working time earns bank time:
 * earned = elapsed * bucketWeight * surgeMultiplier * restRatio / workRatio.
 * CashOut converts the bank into a real-time countdown. Reset ("Time Dump") empties the bank
 * and never touches streak records (A-13).
 *
 * State survives process death and reboot through an [EngineSnapshot]: a rest countdown keeps
 * draining against wall-clock time, a work run comes back paused with its elapsed time intact.
 */
@Singleton
class TimeBankEngine @Inject constructor(
    private val settings: SettingsRepository,
    private val sessions: SessionRepository,
    private val surge: SurgeCalculator,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _state = MutableStateFlow(BankState())
    val state: StateFlow<BankState> = _state.asStateFlow()
    private val _events = MutableSharedFlow<EngineEvent>(extraBufferCapacity = 16)
    val events: SharedFlow<EngineEvent> = _events.asSharedFlow()

    private var tickJob: Job? = null
    private var bankExact = 0.0
    private var lastTick = 0L
    private var lastPersist = 0L
    private var maxMultiplier = 1f
    private var sessionDeferred: Deferred<Long>? = null

    /** Conflated and consumed by one coroutine, so older snapshots can never overwrite newer ones. */
    private val snapshots = Channel<EngineSnapshot>(Channel.CONFLATED)
    private val decayLock = Mutex()

    init {
        scope.launch { for (snapshot in snapshots) settings.saveSnapshot(snapshot) }
        scope.launch {
            restore()
            applyPendingDecay()
        }
    }

    private suspend fun restore() {
        val snap = settings.snapshot.first()
        val preset = sessions.presetById(settings.selectedPresetId.first()) ?: sessions.defaultPreset()
        val tag = sessions.tagById(settings.selectedTagId.first())
        sessions.closeOrphanBankSessions(snap.elapsedMs)
        synchronized(this) {
            if (_state.value.mode != BankMode.IDLE) return@synchronized // the user already started something
            var bank = snap.bankMs.toDouble()
            var mode = BankMode.IDLE
            var elapsed = snap.elapsedMs
            if (snap.mode == BankMode.RESTING.name) {
                bank -= (System.currentTimeMillis() - snap.savedAt).coerceAtLeast(0)
                elapsed = 0
                if (bank > 0) mode = BankMode.RESTING
            }
            bankExact = bank.coerceAtLeast(0.0)
            _state.value = _state.value.copy(
                mode = mode,
                elapsedMs = elapsed,
                bankMs = bankExact.toLong(),
                surgeTier = surge.tierFor(elapsed),
                workRatio = preset?.workRatio ?: 5,
                restRatio = preset?.restRatio ?: 1,
                presetId = preset?.id,
                bucket = tag,
            )
            if (mode == BankMode.RESTING) {
                lastTick = SystemClock.elapsedRealtime()
                ensureTicking()
            }
        }
    }

    @Synchronized
    fun start() {
        if (_state.value.mode == BankMode.WORKING) return
        lastTick = SystemClock.elapsedRealtime()
        _state.value = _state.value.copy(mode = BankMode.WORKING)
        if (sessionDeferred == null) {
            val s = _state.value
            sessionDeferred = scope.async { sessions.startBankSession(s.presetId, s.bucket?.id) }
        }
        persistState()
        ensureTicking()
    }

    @Synchronized
    fun pause() {
        if (_state.value.mode == BankMode.IDLE) return
        _state.value = _state.value.copy(mode = BankMode.IDLE)
        persistState()
    }

    /** Converts the bank into a countdown and closes the work session. */
    @Synchronized
    fun cashOut() {
        val s = _state.value
        if (s.mode == BankMode.RESTING || bankExact < 1.0) return
        finishSession(s.elapsedMs)
        lastTick = SystemClock.elapsedRealtime()
        _state.value = s.copy(mode = BankMode.RESTING, elapsedMs = 0, surgeTier = SurgeTier.NONE)
        persistState()
        ensureTicking()
    }

    /** Time Dump: empties the bank. Streak records are not modified. */
    @Synchronized
    fun reset() {
        finishSession(_state.value.elapsedMs)
        bankExact = 0.0
        _state.value = _state.value.copy(mode = BankMode.IDLE, elapsedMs = 0, bankMs = 0, surgeTier = SurgeTier.NONE)
        persistState()
    }

    @Synchronized
    fun setRatio(preset: RatioPreset) {
        _state.value = _state.value.copy(workRatio = preset.workRatio, restRatio = preset.restRatio, presetId = preset.id)
        scope.launch { settings.setSelectedPresetId(preset.id) }
    }

    @Synchronized
    fun setBucket(tag: BucketTag?) {
        _state.value = _state.value.copy(bucket = tag)
        scope.launch { settings.setSelectedTagId(tag?.id ?: -1L) }
    }

    /**
     * Applies the user's decay once for every local midnight since the last application. Safe to call
     * any number of times: the worker, app start and restore all call it, and the last-applied day
     * guards against double decay. Capped at 30 missed days.
     */
    suspend fun applyPendingDecay() {
        decayLock.withLock {
            val today = dayKey()
            val last = settings.lastDecayDay.first()
            if (last.isEmpty()) {
                settings.setLastDecayDay(today)
                return@withLock
            }
            val missed = daysBetween(last, today).coerceIn(0, 30)
            if (missed > 0) {
                val keep = 1.0 - settings.settings.first().decayPercent.coerceIn(0, 100) / 100.0
                synchronized(this) {
                    bankExact *= keep.pow(missed)
                    _state.value = _state.value.copy(bankMs = bankExact.toLong())
                    persistState()
                }
                settings.setLastDecayDay(today)
            }
        }
    }

    private fun finishSession(durationMs: Long) {
        val deferred = sessionDeferred ?: return
        val multiplier = maxMultiplier
        sessionDeferred = null
        maxMultiplier = 1f
        scope.launch {
            sessions.finishBankSession(deferred.await(), System.currentTimeMillis(), durationMs, multiplier)
        }
    }

    private fun persistState() {
        val s = _state.value
        snapshots.trySend(EngineSnapshot(bankExact.toLong(), s.mode.name, s.elapsedMs, System.currentTimeMillis()))
    }

    private fun ensureTicking() {
        if (tickJob?.isActive == true) return
        tickJob = scope.launch {
            while (isActive) {
                delay(TICK_MS)
                if (!tick()) break
            }
        }
    }

    /** Returns false when the loop should stop. */
    @Synchronized
    private fun tick(): Boolean {
        val now = SystemClock.elapsedRealtime()
        val delta = now - lastTick
        lastTick = now
        val s = _state.value
        when (s.mode) {
            BankMode.IDLE -> return false
            BankMode.WORKING -> {
                val elapsed = s.elapsedMs + delta
                val tier = surge.tierFor(elapsed)
                val weight = s.bucket?.weight ?: 1f
                bankExact += delta * weight * tier.multiplier * s.restRatio / s.workRatio.coerceAtLeast(1)
                if (tier > s.surgeTier) {
                    maxMultiplier = maxOf(maxMultiplier, tier.multiplier)
                    _events.tryEmit(EngineEvent.SurgeBoundary(tier))
                }
                _state.value = s.copy(elapsedMs = elapsed, bankMs = bankExact.toLong(), surgeTier = tier)
            }
            BankMode.RESTING -> {
                bankExact -= delta
                if (bankExact <= 0.0) {
                    bankExact = 0.0
                    _state.value = s.copy(mode = BankMode.IDLE, bankMs = 0)
                    _events.tryEmit(EngineEvent.BankDepleted)
                    persistState()
                    return false
                }
                _state.value = s.copy(bankMs = bankExact.toLong())
            }
        }
        if (now - lastPersist > PERSIST_INTERVAL_MS) {
            lastPersist = now
            persistState()
        }
        return true
    }

    private companion object {
        const val TICK_MS = 250L
        const val PERSIST_INTERVAL_MS = 10_000L
    }
}
