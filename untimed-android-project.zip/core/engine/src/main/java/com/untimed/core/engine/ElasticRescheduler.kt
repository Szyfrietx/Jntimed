// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.engine

import com.untimed.core.model.TimeBlock
import javax.inject.Inject

/**
 * Real-time elastic rescheduling (Q7=A). Re-anchors blocks from [fromIndex] onward to run back to back
 * starting at [anchorMs], preserving each block's duration. One rule covers both cases:
 * early completion pulls later blocks forward in time; overrun pushes them back.
 */
class ElasticRescheduler @Inject constructor() {
    fun cascade(blocks: List<TimeBlock>, fromIndex: Int, anchorMs: Long): List<TimeBlock> {
        var cursor = anchorMs
        return blocks.mapIndexed { i, b ->
            if (i < fromIndex) {
                b
            } else {
                val duration = b.scheduledEnd - b.scheduledStart
                val moved = b.copy(scheduledStart = cursor, scheduledEnd = cursor + duration)
                cursor += duration
                moved
            }
        }
    }
}
