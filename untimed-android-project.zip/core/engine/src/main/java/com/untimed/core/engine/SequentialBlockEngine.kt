// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.engine

import com.untimed.core.data.SessionRepository
import com.untimed.core.model.TimeBlock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs

data class ChainState(
    val running: Boolean = false,
    val activeBlockId: Long? = null,
    val activeTitle: String? = null,
    /** Negative while the active block overruns. */
    val remainingMs: Long = 0,
)

/**
 * Runs blocks back to back. Auto-advance blocks complete at their duration; others keep running into
 * overrun while later blocks shift forward in real time. CompleteActive handles early completion (Q7=A).
 */
@Singleton
class SequentialBlockEngine @Inject constructor(
    private val sessions: SessionRepository,
    private val rescheduler: ElasticRescheduler,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lock = Mutex()
    private val _state = MutableStateFlow(ChainState())
    val state: StateFlow<ChainState> = _state.asStateFlow()
    private val _events = MutableSharedFlow<EngineEvent>(extraBufferCapacity = 16)
    val events: SharedFlow<EngineEvent> = _events.asSharedFlow()
    private var tickJob: Job? = null

    fun start(sessionId: Long) {
        scope.launch { lock.withLock { begin(sessionId) } }
    }

    fun stop() {
        scope.launch {
            lock.withLock {
                tickJob?.cancel()
                _state.value = ChainState()
            }
        }
    }

    /** Early completion: ends the active block now and starts the next immediately. */
    fun completeActive() {
        scope.launch {
            lock.withLock {
                val id = _state.value.activeBlockId ?: return@withLock
                sessions.blockById(id)?.let { complete(it, System.currentTimeMillis()) }
            }
        }
    }

    private suspend fun begin(sessionId: Long) {
        var blocks = sessions.blocksNow(sessionId)
        if (blocks.size < SessionRepository.MIN_BLOCKS) return
        if (blocks.all { it.actualEnd != null }) blocks = blocks.map { it.copy(actualStart = null, actualEnd = null) }
        val first = blocks.indexOfFirst { it.actualEnd == null }
        val now = System.currentTimeMillis()
        val plan = rescheduler.cascade(blocks, first, now).toMutableList()
        plan[first] = plan[first].copy(actualStart = now)
        sessions.saveBlocks(plan)
        publish(plan[first], plan[first].durationMs) // no alert: the user just pressed Start
        if (tickJob?.isActive != true) {
            tickJob = scope.launch {
                while (isActive && _state.value.running) {
                    delay(TICK_MS)
                    lock.withLock { tick() }
                }
            }
        }
    }

    private suspend fun tick() {
        val id = _state.value.activeBlockId ?: return
        val now = System.currentTimeMillis()
        val block = sessions.blockById(id)
        if (block == null) { // deleted while running
            val all = sessions.blocksNow(sessions.chainSessionId())
            val next = all.indexOfFirst { it.actualEnd == null }
            if (next < 0) finish() else startAt(all, next, now)
            return
        }
        val remaining = block.durationMs - (now - (block.actualStart ?: now))
        if (remaining <= 0 && block.autoAdvance) {
            complete(block, now)
            return
        }
        publish(block, remaining)
        if (remaining < 0) shiftFollowers(block, now)
    }

    /** While a block overruns, later blocks track "now" so the schedule stays honest. */
    private suspend fun shiftFollowers(block: TimeBlock, now: Long) {
        val all = sessions.blocksNow(block.sessionId)
        val idx = all.indexOfFirst { it.id == block.id }
        val follower = all.getOrNull(idx + 1) ?: return
        if (abs(follower.scheduledStart - now) <= SHIFT_TOLERANCE_MS) return
        val moved = rescheduler.cascade(all, idx + 1, now)
        sessions.saveBlocks(moved.drop(idx + 1))
    }

    private suspend fun complete(block: TimeBlock, now: Long) {
        val all = sessions.blocksNow(block.sessionId).toMutableList()
        val idx = all.indexOfFirst { it.id == block.id }
        if (idx < 0) return
        all[idx] = all[idx].copy(actualEnd = now)
        val next = all.indexOfFirst { it.actualEnd == null }
        if (next < 0) {
            sessions.saveBlocks(all)
            finish()
        } else {
            startAt(all, next, now)
        }
    }

    private suspend fun startAt(all: List<TimeBlock>, index: Int, now: Long) {
        val plan = rescheduler.cascade(all, index, now).toMutableList()
        plan[index] = plan[index].copy(actualStart = now)
        sessions.saveBlocks(plan)
        publish(plan[index], plan[index].durationMs)
        _events.tryEmit(EngineEvent.BlockAlert(plan[index].title))
    }

    private fun finish() {
        _state.value = ChainState()
        _events.tryEmit(EngineEvent.ChainFinished)
    }

    private fun publish(block: TimeBlock, remaining: Long) {
        _state.value = ChainState(true, block.id, block.title, remaining)
    }

    private companion object {
        const val TICK_MS = 500L
        const val SHIFT_TOLERANCE_MS = 1000L
    }
}
