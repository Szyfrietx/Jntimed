// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.model

/** Earning multiplier tiers. Thresholds live in SurgeCalculator (1.5x at 30 min, 2.0x at 60 min). */
enum class SurgeTier(val multiplier: Float) {
    NONE(1.0f),
    TIER_1(1.5f),
    TIER_2(2.0f),
}
