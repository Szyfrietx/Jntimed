// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Weight scales time-bank earning. Range 0.5–2.0 in 0.1 steps (A-11). */
@Entity(tableName = "bucket_tags", indices = [Index("name")])
data class BucketTag(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val weight: Float = 1f,
    val colorHex: String = "#FF6750A4",
)
