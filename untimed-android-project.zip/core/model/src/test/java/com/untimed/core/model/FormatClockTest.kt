// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.model

import org.junit.Assert.assertEquals
import org.junit.Test

class FormatClockTest {
    @Test fun formatsMinutesAndSeconds() = assertEquals("02:05", formatClock(125_000))
    @Test fun formatsHours() = assertEquals("1:01:01", formatClock(3_661_000))
    @Test fun prefixesOverrunWithMinus() = assertEquals("-00:30", formatClock(-30_000))
    @Test fun zero() = assertEquals("00:00", formatClock(0))
}
