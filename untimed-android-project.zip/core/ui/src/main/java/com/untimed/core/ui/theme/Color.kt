// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

val DefaultPalette = listOf("#FF6750A4", "#FF625B71", "#FF7D5260")

/** Parses #RRGGBB or #AARRGGBB; falls back to [default] on malformed input. */
fun String?.toColorOrDefault(default: Color): Color =
    try {
        Color(android.graphics.Color.parseColor(this))
    } catch (e: IllegalArgumentException) {
        default
    } catch (e: NullPointerException) {
        default
    }

fun Color.toHex(): String = String.format("#%08X", toArgb())
