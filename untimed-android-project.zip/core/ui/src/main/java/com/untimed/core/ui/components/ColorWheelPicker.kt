// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.github.skydoves.colorpicker.compose.HsvColorPicker
import com.github.skydoves.colorpicker.compose.rememberColorPickerController

/**
 * HSV color wheel from com.github.skydoves:colorpicker-compose:1.1.0 (Q1=A).
 * Re-create with `key(...)` when [initialColor] must change from outside.
 */
@Composable
fun ColorWheelPicker(
    initialColor: Color,
    onColorChanged: (Color) -> Unit,
    modifier: Modifier = Modifier,
) {
    val controller = rememberColorPickerController()
    HsvColorPicker(
        modifier = modifier.fillMaxWidth().height(220.dp),
        controller = controller,
        initialColor = initialColor,
        onColorChanged = { envelope -> if (envelope.fromUser) onColorChanged(envelope.color) },
    )
}
