// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.untimed.core.model.RatioPreset
import kotlinx.coroutines.flow.Flow

@Dao
interface RatioPresetDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(preset: RatioPreset): Long

    @Query("SELECT * FROM ratio_presets ORDER BY workRatio ASC")
    fun observeAll(): Flow<List<RatioPreset>>

    @Query("SELECT * FROM ratio_presets WHERE id = :id")
    suspend fun byId(id: Long): RatioPreset?

    @Query("SELECT COUNT(*) FROM ratio_presets WHERE workRatio = :ratio")
    suspend fun countByRatio(ratio: Int): Int

    @Query("SELECT * FROM ratio_presets WHERE isDefault = 1 LIMIT 1")
    suspend fun findDefault(): RatioPreset?
}
