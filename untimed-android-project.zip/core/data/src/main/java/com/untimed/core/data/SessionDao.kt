// Untimed v1.0.0 | 2026-10-06 | P-UNTIMED-ANDROID-001
package com.untimed.core.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.untimed.core.model.Session
import kotlinx.coroutines.flow.Flow

@Dao
interface SessionDao {
    @Insert
    suspend fun insert(session: Session): Long

    @Update
    suspend fun update(session: Session)

    @Query("SELECT * FROM sessions WHERE id = :id")
    suspend fun byId(id: Long): Session?

    @Query("SELECT * FROM sessions WHERE kind = 'BANK' ORDER BY startTime DESC")
    fun observeBankSessions(): Flow<List<Session>>

    @Query("SELECT * FROM sessions WHERE kind = 'CHAIN' AND isActive = 1 LIMIT 1")
    suspend fun activeChainSession(): Session?

    /** Closes bank sessions left open by a process death or reboot. */
    @Query("UPDATE sessions SET isActive = 0, endTime = :now, durationMs = :elapsedMs WHERE kind = 'BANK' AND isActive = 1")
    suspend fun closeOrphanBankSessions(now: Long, elapsedMs: Long)

    @Query("DELETE FROM sessions WHERE isActive = 0 AND kind = 'BANK'")
    suspend fun deleteFinished()
}
